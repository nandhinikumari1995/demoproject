package testscripts1;

import genericUtility.BaseTestCalss1;
import pageObject.VtigerHomePages;
import pageObject.Vtiger_ProductInfoLink;

public class SampleTest1 extends BaseTestCalss1  {
	
public void testProductInfoLink() {
		
		Vtiger_ProductInfoLink ProductInfoLink = VtigerHomePages.navigateToProductInfoLink();
		
		//ProductInfoLink.CreateProduct();
	    
		ProductInfoLink.typeProductName(excelUtil.getDataFromExcel("Sheet1", 7, 3));
	   
		ProductInfoLink.saveoption();
		
		ProductInfoLink.Unitprice(excelUtil.getDataFromExcel("Sheet1",7,4));
	    
		ProductInfoLink.saveoption1();
	    
		        
}

}
