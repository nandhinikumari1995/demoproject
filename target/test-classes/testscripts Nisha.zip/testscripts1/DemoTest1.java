package testscripts1;

import org.testng.annotations.Test;

import genericUtility.BaseTestCalss1;
import pageObject.VtigerHomePages;
import pageObject.Vtiger_ProductInfoLink;

public class DemoTest1 extends BaseTestCalss1 {
	@Test(groups= {"Sanity"})
	public void testProductInfoLink() throws InterruptedException {
		
		Vtiger_ProductInfoLink ProductInfoLink = VtigerHomePages.navigateToProductInfoLink();
		Thread.sleep(5000);
		ProductInfoLink.CreateProduct();
		Thread.sleep(5000);
	    
		ProductInfoLink.typeProductName(excelUtil.getDataFromExcel("Sheet1",7, 2));
	   
		ProductInfoLink.saveoption();
		
     	ProductInfoLink.Unitprice(excelUtil.getDataFromExcel("Sheet1",7,3));
	    
		ProductInfoLink.saveoption1();
	    
		        
}
}