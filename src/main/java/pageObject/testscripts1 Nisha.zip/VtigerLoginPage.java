package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VtigerLoginPage {
	
private WebDriver driver;
	
	@FindBy(name="user_name")
	private WebElement usernameTB;
	
	@FindBy(name="user_password")
	private WebElement passwordTB;
	
	@FindBy(id="submitButton")
	private WebElement loginbtn;
	
	public VtigerLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	public VtigerHomePages loginTovtiger(String username,String password) {
		
		usernameTB.sendKeys(username);
		passwordTB.sendKeys(password);
		
		loginbtn.click();
		return new VtigerHomePages(driver);
	}
}



