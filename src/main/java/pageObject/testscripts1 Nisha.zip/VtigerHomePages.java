package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VtigerHomePages {

private WebDriver driver;
	
	@FindBy(xpath="//a[text()='Products']")
	private WebElement productlink ;
	
	@FindBy(css="img[title='Create Product...']")
	private WebElement createproduct;
	
	@FindBy(xpath="//a[text()='Logout']")
	private WebElement logoutlink;
	
	public VtigerHomePages(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
	public Vtiger_ProductInfoLink navigateToProductInfoLink() {
		productlink.click();
		return new Vtiger_ProductInfoLink(driver); 
	}
	
	public void logout() {
		createproduct.click();
		logoutlink.click();
	}
   
	}

	

//}
