package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Vtiger_ProductInfoLink {
	
	@FindBy(xpath = "[title='Create Product...']" )
	private WebElement CreateProduct;
		
	@FindBy(xpath = "//input[@name='productname']")
	private WebElement Productname;
	
	@FindBy(xpath="//input[@class='crmButton small save']")
	private WebElement saveBTN;
		
    @FindBy(xpath = "//input[@id='unit_price']")
	 private WebElement pricingvalue;
    
    @FindBy(xpath="//input[@class='crmButton small save']")
	private WebElement saveBTN1;
    
    
    public Vtiger_ProductInfoLink(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	public void CreateProduct() {
		CreateProduct.click();
	  	}
	public void typeProductName(String ProName ) {
		Productname.sendKeys(ProName);
		
	}
	public void saveoption() {
		saveBTN.click();
	  	}

	public void Unitprice(String UnitPrice) {
		pricingvalue .sendKeys(UnitPrice);

	}
	public void saveoption1() {
		saveBTN.click();
	  	}
	/*public WebElement getCreateProduct() {
		return CreateProduct;
	}
	public void setCreateProduct(WebElement createProduct) {
		CreateProduct = createProduct;
	}*/
		
	}

	